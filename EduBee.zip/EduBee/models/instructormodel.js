var db = require('./db');

module.exports ={

	get: function(id, callback){
		var sql = "select * from instructor where ID=?";
		db.getResults(sql, [id], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback([]);
			}
		});
	},

	getAll: function(callback){
		var sql = "select * from instructor";
		db.getResults(sql, null,  function(result){
			if(result.length > 0){
				callback(result);
			}else{
				callback([]);
			}
		});
	},


	insert: function(user, callback){
		var sql = "insert into instructor values(?, ?, ?, ?, ?)";

		db.execute(sql, [user.id, user.name, user.email, user.phone_number, user.courses], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},

	update: function(user, callback){
		var sql = "update instructor set ID=?, name=?, email=?, phone_number=?, courses=? where ID=?";
		db.execute(sql, [user.ID, user.name, user.email, user.phone_number, user.courses, user.ID], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},

	delete: function(id, callback){
		var sql = "delete from instructor where ID=?";
		db.execute(sql, [id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	}
}
